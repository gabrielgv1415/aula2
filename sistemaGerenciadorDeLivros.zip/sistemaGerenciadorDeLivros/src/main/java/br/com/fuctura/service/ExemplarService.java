package br.com.fuctura.service;

public class ExemplarService {

}
