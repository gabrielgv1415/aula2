package br.com.fuctura.domain;

public class Autor {
	
	private Long id;
	private String nome;

}
