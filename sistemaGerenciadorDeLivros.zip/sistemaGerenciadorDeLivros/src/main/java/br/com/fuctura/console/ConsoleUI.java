package br.com.fuctura.console;

public class ConsoleUI {

}
