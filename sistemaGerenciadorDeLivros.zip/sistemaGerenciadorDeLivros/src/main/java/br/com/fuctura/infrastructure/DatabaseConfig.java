package br.com.fuctura.infrastructure;

public class DatabaseConfig {

}
