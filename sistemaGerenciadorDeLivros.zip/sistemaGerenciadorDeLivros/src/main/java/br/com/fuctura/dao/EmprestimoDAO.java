package br.com.fuctura.dao;

public class EmprestimoDAO {

}
