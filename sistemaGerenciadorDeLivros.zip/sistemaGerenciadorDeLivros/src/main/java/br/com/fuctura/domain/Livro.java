package br.com.fuctura.domain;

public class Livro {
	
	private Long id;
	private String titulo;
	

}
