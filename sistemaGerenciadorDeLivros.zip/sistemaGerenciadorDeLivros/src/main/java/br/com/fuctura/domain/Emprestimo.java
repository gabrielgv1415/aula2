package br.com.fuctura.domain;

import java.time.LocalDate;

public class Emprestimo {
	
	private Long id;
	private LocalDate dataEmprestimo;
	private LocalDate dataDevolucao;
	
	
	

}
