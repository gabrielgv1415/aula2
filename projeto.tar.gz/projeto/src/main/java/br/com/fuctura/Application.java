package br.com.fuctura;

import br.com.fuctura.console.MenuPrincipal;

public class Application {

	public static void main(String[] args) throws Exception {
		
		new MenuPrincipal().iniciar();
	

	}

}
