package br.com.fuctura.dao;

public class AutorDAO {

}
