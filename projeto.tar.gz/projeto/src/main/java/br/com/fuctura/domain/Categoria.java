package br.com.fuctura.domain;

public class Categoria {
	
	private Long id;

	private String nome;

}
