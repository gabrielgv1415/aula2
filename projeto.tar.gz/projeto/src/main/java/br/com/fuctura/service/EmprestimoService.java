package br.com.fuctura.service;

public class EmprestimoService {

}
