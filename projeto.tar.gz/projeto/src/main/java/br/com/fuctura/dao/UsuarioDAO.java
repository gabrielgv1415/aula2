package br.com.fuctura.dao;

public class UsuarioDAO {

}
