package br.com.fuctura.service;

import java.sql.SQLException;

import br.com.fuctura.dao.LivroDAO;
import br.com.fuctura.domain.Livro;

public class LivroService {

	public void cadastrar(String nomeLivro) throws SQLException {
		
		LivroDAO dao = new LivroDAO();
		
		Livro livro = new Livro();
		livro.setTitulo(nomeLivro);
		
		dao.cadastrar(livro);
		
	}

}
