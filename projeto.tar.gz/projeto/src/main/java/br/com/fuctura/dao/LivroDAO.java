package br.com.fuctura.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import br.com.fuctura.domain.Livro;
import br.com.fuctura.infrastructure.ConnectionFactory;

public class LivroDAO {
	
	public List<Livro> consultarTodos(){
		return null;
	}
	
	public Livro consultarPorId(Livro livro) {
		return null;
		
	}

	public void cadastrar(Livro livro) throws SQLException {
		
		ConnectionFactory fabrica = new ConnectionFactory();
		
		Connection conexao = fabrica.getConnection();
		
		String comandoSQL = "insert into livro (titulo) values(?)";
		
		PreparedStatement stm = conexao.prepareStatement(comandoSQL);
		
		stm.setString(1, livro.getTitulo());
		
		stm.execute();//play
		
	}
	
}
