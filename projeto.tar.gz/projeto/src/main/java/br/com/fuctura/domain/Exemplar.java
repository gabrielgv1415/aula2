package br.com.fuctura.domain;

public class Exemplar {

	private Long id;

	private String codigoTombo;

	private boolean disponive;
}
