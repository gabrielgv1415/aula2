package br.com.fuctura.domain;

public class Usuario {
	
	private Long id;
	private String nome;

}
